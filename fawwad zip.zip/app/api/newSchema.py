from fastapi import FastAPI, APIRouter, Depends, HTTPException, status
from sqlmodel import Session, select
from typing import List
from datetime import datetime
from passlib.hash import bcrypt
from app.database.connection import get_session

from app.models import (
    User, UserCreate, UserRead, UserUpdate,
    Profile, ProfileCreate, ProfileRead, ProfileUpdate,
    RedditPost, RedditPostCreate, RedditPostRead,
    AIAnalysis, AIAnalysisCreate, AIAnalysisRead,
    Notification, NotificationCreate, NotificationRead
)

router = APIRouter(prefix="/posts", tags=["Posts"])

router.post("/users", response_model=UserRead, status_code=status.HTTP_201_CREATED)
def create_user(user: UserCreate, session: Session = Depends(get_session)):
    """Create a new user"""
    
    # Check if user already exists
    existing_user = session.execute(
        select(User).where(User.email == user.email)
    )

    user = existing_user.first()
    
    if user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    # Hash password
    hashed_password = bcrypt.hash(user.password)
    
    # Create user instance
    db_user = User(
        email=user.email,
        hashed_password=hashed_password,
        full_name=user.full_name,
        is_active=user.is_active,
        subscription_tier=user.subscription_tier,
    )
    
    session.add(db_user)
    session.commit()
    session.refresh(db_user)
    
    return db_user


router.get("/users/{user_id}", response_model=UserRead)
def get_user(user_id: int, session: Session = Depends(get_session)):
    """Get user by ID"""
    user = session.get(User, user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    return user


router.get("/users", response_model=List[UserRead])
def list_users(
    skip: int = 0,
    limit: int = 100,
    session: Session = Depends(get_session)
):
    """List all users with pagination"""
    users = session.exec(
        select(User).offset(skip).limit(limit)
    ).all()
    return users


router.patch("/users/{user_id}", response_model=UserRead)
def update_user(
    user_id: int,
    user_update: UserUpdate,
    session: Session = Depends(get_session)
):
    """Update user information"""
    user = session.get(User, user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # Update only provided fields
    user_data = user_update.model_dump(exclude_unset=True)
    for key, value in user_data.items():
        setattr(user, key, value)
    
    user.updated_at = datetime.utcnow()
    session.add(user)
    session.commit()
    session.refresh(user)
    
    return user


router.delete("/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(user_id: int, session: Session = Depends(get_session)):
    """Delete a user"""
    user = session.get(User, user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    session.delete(user)
    session.commit()
    
    return None


# ============================================
# PROFILE ENDPOINTS
# ============================================

router.post("/profiles", response_model=ProfileRead, status_code=status.HTTP_201_CREATED)
def create_profile(
    profile: ProfileCreate,
    user_id: int,
    session: Session = Depends(get_session)
):
    """Create a new monitoring profile"""
    # Verify user exists
    user = session.get(User, user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    db_profile = Profile(**profile.model_dump(), user_id=user_id)
    session.add(db_profile)
    session.commit()
    session.refresh(db_profile)
    
    return db_profile


router.get("/profiles/{profile_id}", response_model=ProfileRead)
def get_profile(profile_id: int, session: Session = Depends(get_session)):
    """Get profile by ID"""
    profile = session.get(Profile, profile_id)
    if not profile:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Profile not found"
        )
    return profile


router.get("/users/{user_id}/profiles", response_model=List[ProfileRead])
def list_user_profiles(
    user_id: int,
    active_only: bool = False,
    session: Session = Depends(get_session)
):
    """List all profiles for a user"""
    query = select(Profile).where(Profile.user_id == user_id)
    
    if active_only:
        query = query.where(Profile.is_active == True)
    
    profiles = session.exec(query).all()
    return profiles


router.patch("/profiles/{profile_id}", response_model=ProfileRead)
def update_profile(
    profile_id: int,
    profile_update: ProfileUpdate,
    session: Session = Depends(get_session)
):
    """Update profile settings"""
    profile = session.get(Profile, profile_id)
    if not profile:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Profile not found"
        )
    
    profile_data = profile_update.model_dump(exclude_unset=True)
    for key, value in profile_data.items():
        setattr(profile, key, value)
    
    profile.updated_at = datetime.utcnow()
    session.add(profile)
    session.commit()
    session.refresh(profile)
    
    return profile


# ============================================
# REDDIT POST ENDPOINTS
# ============================================

router.post("/posts", response_model=RedditPostRead, status_code=status.HTTP_201_CREATED)
def create_reddit_post(
    post: RedditPostCreate,
    session: Session = Depends(get_session)
):
    """Create a new Reddit post entry"""
    # Check for duplicate reddit_id
    existing = session.exec(
        select(RedditPost).where(RedditPost.reddit_id == post.reddit_id)
    ).first()
    
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Post already exists"
        )
    
    db_post = RedditPost(**post.model_dump())
    session.add(db_post)
    session.commit()
    session.refresh(db_post)
    
    return db_post


router.get("/posts/{post_id}", response_model=RedditPostRead)
def get_reddit_post(post_id: int, session: Session = Depends(get_session)):
    """Get Reddit post by ID"""
    post = session.get(RedditPost, post_id)
    if not post:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Post not found"
        )
    return post


router.get("/profiles/{profile_id}/posts", response_model=List[RedditPostRead])
def list_profile_posts(
    profile_id: int,
    skip: int = 0,
    limit: int = 100,
    status_filter: str = None,
    session: Session = Depends(get_session)
):
    """List all posts for a profile with optional status filter"""
    query = select(RedditPost).where(
        RedditPost.profile_id == profile_id
    ).order_by(RedditPost.created_utc.desc())
    
    if status_filter:
        query = query.where(RedditPost.processing_status == status_filter)
    
    posts = session.exec(query.offset(skip).limit(limit)).all()
    return posts


router.get("/posts/{post_id}/analysis", response_model=AIAnalysisRead)
def get_post_analysis(post_id: int, session: Session = Depends(get_session)):
    """Get AI analysis for a specific post"""
    analysis = session.exec(
        select(AIAnalysis).where(AIAnalysis.post_id == post_id)
    ).first()
    
    if not analysis:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Analysis not found for this post"
        )
    
    return analysis


# ============================================
# NOTIFICATION ENDPOINTS
# ============================================

router.post("/notifications", response_model=NotificationRead, status_code=status.HTTP_201_CREATED)
def create_notification(
    notification: NotificationCreate,
    session: Session = Depends(get_session)
):
    """Create a new notification"""
    db_notification = Notification(**notification.model_dump())
    session.add(db_notification)
    session.commit()
    session.refresh(db_notification)
    
    return db_notification


router.get("/users/{user_id}/notifications", response_model=List[NotificationRead])
def list_user_notifications(
    user_id: int,
    unread_only: bool = False,
    limit: int = 50,
    session: Session = Depends(get_session)
):
    """List notifications for a user"""
    query = select(Notification).where(
        Notification.user_id == user_id
    ).order_by(Notification.created_at.desc())
    
    if unread_only:
        query = query.where(Notification.is_read == False)
    
    notifications = session.exec(query.limit(limit)).all()
    return notifications


router.patch("/notifications/{notification_id}/read")
def mark_notification_read(
    notification_id: int,
    session: Session = Depends(get_session)
):
    """Mark notification as read"""
    notification = session.get(Notification, notification_id)
    if not notification:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Notification not found"
        )
    
    notification.is_read = True
    notification.read_at = datetime.utcnow()
    session.add(notification)
    session.commit()
    
    return {"status": "success"}


# ============================================
# ANALYTICS ENDPOINTS
# ============================================

router.get("/profiles/{profile_id}/analytics/sentiment")
def get_sentiment_analytics(
    profile_id: int,
    session: Session = Depends(get_session)
):
    """Get sentiment analytics for a profile"""
    from sqlalchemy import func
    
    # Count posts by sentiment
    query = select(
        AIAnalysis.sentiment_label,
        func.count(AIAnalysis.id).label("count")
    ).where(
        AIAnalysis.profile_id == profile_id
    ).group_by(AIAnalysis.sentiment_label)
    
    results = session.exec(query).all()
    
    sentiment_counts = {
        sentiment: count for sentiment, count in results
    }
    
    return sentiment_counts


router.get("/profiles/{profile_id}/analytics/pain-points")
def get_pain_point_analytics(
    profile_id: int,
    session: Session = Depends(get_session)
):
    """Get pain point analytics for a profile"""
    from sqlalchemy import func
    
    # Get pain point statistics
    query = select(
        AIAnalysis.pain_point_category,
        func.count(AIAnalysis.id).label("count")
    ).where(
        AIAnalysis.profile_id == profile_id,
        AIAnalysis.has_pain_point == True
    ).group_by(AIAnalysis.pain_point_category)
    
    results = session.exec(query).all()
    
    pain_points = {
        category: count for category, count in results if category
    }
    
    return pain_points


# ============================================
# SEARCH ENDPOINTS
# ============================================

router.get("/profiles/{profile_id}/posts/search")
def search_posts(
    profile_id: int,
    query: str = None,
    sentiment: str = None,
    subreddit: str = None,
    has_pain_point: bool = None,
    limit: int = 50,
    session: Session = Depends(get_session)
):
    """Search posts with various filters"""
    from sqlalchemy import or_
    
    # Base query with join to AI analysis
    base_query = select(RedditPost).join(
        AIAnalysis, 
        RedditPost.id == AIAnalysis.post_id,
        isouter=True
    ).where(RedditPost.profile_id == profile_id)
    
    # Apply filters
    if query:
        base_query = base_query.where(
            or_(
                RedditPost.title.ilike(f"%{query}%"),
                RedditPost.selftext.ilike(f"%{query}%")
            )
        )
    
    if sentiment:
        base_query = base_query.where(AIAnalysis.sentiment_label == sentiment)
    
    if subreddit:
        base_query = base_query.where(RedditPost.subreddit == subreddit)
    
    if has_pain_point is not None:
        base_query = base_query.where(AIAnalysis.has_pain_point == has_pain_point)
    
    posts = session.exec(
        base_query.order_by(RedditPost.created_utc.desc()).limit(limit)
    ).all()
    
    return posts
