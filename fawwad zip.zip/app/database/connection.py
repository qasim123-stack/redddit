# """Database connection and session management"""

# from sqlalchemy import create_engine
# from sqlalchemy.ext.declarative import declarative_base
# from sqlalchemy.orm import sessionmaker
# from app.core.config import settings

# # Create SQLAlchemy engine
# engine = create_engine(
#     settings.DATABASE_URL,
#     pool_pre_ping=True,
#     pool_size=10,
#     max_overflow=20,
#     echo=settings.DEBUG
# )

# # Create session factory
# SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# # Base class for models
# Base = declarative_base()


# def get_db():
#     """
#     Dependency for getting database session
#     Usage in FastAPI: db: Session = Depends(get_db)
#     """
#     db = SessionLocal()
#     try:
#         yield db
#     finally:
#         db.close()


# def init_db():
#     """Initialize database - create all tables"""
#     Base.metadata.create_all(bind=engine)
#     print("Database tables created successfully!")


# def drop_db():
#     """Drop all database tables - USE WITH CAUTION"""
#     Base.metadata.drop_all(bind=engine)
#     print("Database tables dropped!")



import os
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlmodel import SQLModel

# 1. Get DB URL from environment variable (Render will inject DATABASE_URL)
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://admin:qasim123@localhost:5433/reddit-database"  # fallback for local dev
)

# 2. Ensure asyncpg is used for async connections
if DATABASE_URL.startswith("postgresql://"):
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+asyncpg://", 1)

# 3. Create async engine
engine = create_async_engine(
    DATABASE_URL,
    echo=False,          # logs SQL queries, disable in production
    pool_pre_ping=True,
    pool_recycle=300,
)

# 4. Session factory
async_session = async_sessionmaker(
    engine, class_=AsyncSession, expire_on_commit=False
)

# 5. Create tables
async def create_db_and_tables():
    """Create database tables (only run once on startup or via migration)"""
    async with engine.begin() as conn:
        await conn.run_sync(SQLModel.metadata.create_all)

# 6. Dependency for FastAPI
async def get_session() -> AsyncSession:
    """Yield a database session"""
    async with async_session() as session:
        yield session
